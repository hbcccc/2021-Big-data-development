package UI;

import Data.Server;

import java.sql.SQLException;

public class test {

public static void function(A a){
    a = A.getInstance();
}

}

class A{
    private static A instance;
    int content;
    private A(){
        content = 3;
    }
    public static A getInstance(){
        if(instance == null)
            instance = new A();
        return instance;
    }

    public static void main(String[] args) throws SQLException {
        Server server = Server.getServer("1","2,",1,"1,","1");
        //server.getTables();

    }
}
