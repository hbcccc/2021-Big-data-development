package UI;
import Data.Server;
import Data.TableData;
import Data.detailData;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javafx.scene.control.*;

import java.sql.SQLException;
import java.util.List;


public class Main extends Application {

    private static Server server;
    public static void main(String[] args) throws Exception {
        server = Server.getServer("default", "default", 123, "user04", "pass@bingo4");
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        BorderPane bp = new BorderPane();

        /*
        * 菜单模块*/
        MenuBar menuBar = new MenuBar();
        Menu operation = new Menu("  操作  ");
        MenuItem createConnect = new MenuItem("创建连接");
        MenuItem refreshTables = new MenuItem("刷新表格");
        operation.getItems().addAll(createConnect, new SeparatorMenuItem(),refreshTables);

        Menu help = new Menu("帮助");
        MenuItem documentation = new MenuItem("在线文档");
        MenuItem about = new MenuItem("关于...");
        help.getItems().addAll(documentation, about);



//        operation.setStyle("-fx-padding: 0.333333em 0.083333em 0.666667em 0.083333em");
        menuBar.setStyle("-fx-font-size: 20;" +
                "-fx-padding: 0.333333em 0.083333em 0.666667em 0.083333em;" +
                "-fx-background-radius: 20;"
        );

//        mb.prefHeightProperty().bind(primaryStage.widthProperty());
        menuBar.getMenus().addAll(operation, help);
        bp.setTop(menuBar);


        VBox vbox = new VBox();
        TableData tableData = new TableData();
        bp.setLeft(vbox);



        /*
        表的数据的展  示模块
        */
        Label sqlInputLabel  = new Label("在这里输入sql语句");
        Button runButton  = new Button("运行");
        HBox sqlInputZone = new HBox();
        sqlInputZone.getChildren().addAll(sqlInputLabel,new Separator(), runButton);

        Label sqlOutputLabel = new Label("sql执行结果");


        TextArea sqlInputArea = new TextArea();
        sqlInputArea.setPrefColumnCount(15);


        TextArea sqlOutputArea = new TextArea();
        DataTable sqlOutputTable = new DataTable();
        VBox sqlOutputTableArea = sqlOutputTable.getDataTableUI("");
        sqlOutputArea.setEditable(false);
        sqlOutputArea.setPrefHeight(500);


        DataTable dataTable = new DataTable();
        VBox dataTableUI = dataTable.getDataTableUI("");

        VBox centreVB = new VBox();
        centreVB.getChildren().addAll(dataTableUI,sqlInputZone,sqlInputArea,sqlOutputLabel,sqlOutputTableArea);
        centreVB.setPadding(new Insets(25));
        centreVB.setSpacing(20);
        bp.setCenter(centreVB);




        createConnect.setOnAction(event ->{
            Stage createConnectStage = newConnection.getStage();
            newConnection.listenerVBox = vbox;
            newConnection.tableData = tableData;
            newConnection.dataTableUI = dataTableUI;
            createConnectStage.setTitle("创建连接");
            createConnectStage.show();

        });

        runButton.setOnAction(event -> {
            String sqlRequest = sqlInputArea.getText();
            sqlOutputArea.clear();
            System.out.println("请求的sql为:"+sqlRequest);
            try{
                Server server = Server.getServer();
                detailData data =   server.executeSQL(sqlRequest,sqlOutputArea);
                TableView<List<Object>> table = (TableView<List<Object>>)sqlOutputTableArea.getChildren().get(0);
                DataTable.refreshWithDetailData(table,data);
            }catch (Exception e){

                e.printStackTrace();
            }
        });

        refreshTables.setOnAction(event -> {
            System.out.println("ahhhhhhhhh");
            vbox.getChildren().clear();
            tableData.refresh();
            int tablesCount = tableData.getTables().size();
            Hyperlink[] option = new Hyperlink[tablesCount];
            for(int i =0;i<tablesCount;i++ ){
                String tableName = tableData.getTables().get(i);
                int tableIndex = i;
                option[i] = new Hyperlink(tableName);
                option[i].setOnAction(event1 -> {
                    TableView<List<Object>> table = (TableView<List<Object>>)dataTableUI.getChildren().get(0);
                    try {
                        DataTable.reflesh(table,tableName);
                    } catch (Exception e) {
                        System.out.println("具体数据的tableview更新失败");
                    }

                });
            }

            for(int i = 0; i<tablesCount;i++)
                vbox.getChildren().add(option[i]);
            System.out.println("wuhhhhhhhhhh");

        });










        Scene scene = new Scene(bp, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Spark SQL查询分析器");
        primaryStage.setFullScreen(true);
        primaryStage.show();
    }
}
