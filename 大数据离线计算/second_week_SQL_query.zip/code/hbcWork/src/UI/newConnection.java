package UI;

import Data.Server;
import Data.TableData;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class newConnection extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        primaryStage.setTitle("connectionPage");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new Insets(25, 25, 25, 25));
        Scene scene = new Scene(grid, 400, 600);
        primaryStage.setScene(scene);

        Label connectionName = new Label("连接名");
        TextField connectionNameTextField = new TextField();
        grid.add(connectionName,0,1);
        grid.add(connectionNameTextField,1,1);

        Label host= new Label("主机名");
        TextField hostTextField = new TextField();
        grid.add(host,0,2);
        grid.add(hostTextField,1,2);

        Label port= new Label("端口号");
        TextField portTextField = new TextField();
        portTextField.setPrefWidth(2);
        grid.add(port,0,3);
        grid.add(portTextField,1,3);

        Label userName= new Label("用户名");
        TextField userNameTextField = new TextField();
        grid.add(userName,0,4);
        grid.add(userNameTextField,1,4);

        Label passWord= new Label("密码");
        PasswordField passWordTextField = new PasswordField();
        grid.add(passWord,0,5);
        grid.add(passWordTextField,1,5);

        HBox hbBtn = new HBox(10);
        Button confirm = new Button("确认");
        Button cancel  = new Button("取消");
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().addAll(confirm,cancel);
        grid.add(hbBtn,1,6);
        primaryStage.show();
    }

    public static VBox listenerVBox;
    public static TableData tableData;
    public static VBox dataTableUI;

    public static Stage getStage(){
        Stage primaryStage = new Stage();
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new Insets(25, 25, 25, 25));
        Scene scene = new Scene(grid, 400, 600);
        primaryStage.setScene(scene);

        Label connectionName = new Label("连接名");
        TextField connectionNameTextField = new TextField();
        grid.add(connectionName,0,1);
        grid.add(connectionNameTextField,1,1);

        Label host= new Label("url");
        TextField hostTextField = new TextField();
        grid.add(host,0,2);
        grid.add(hostTextField,1,2);

//        Label port= new Label("端口号");
//        TextField portTextField = new TextField();
//        portTextField.setPrefWidth(2);
//        grid.add(port,0,3);
//        grid.add(portTextField,1,3);

        Label userName= new Label("用户名");
        TextField userNameTextField = new TextField();
        grid.add(userName,0,4);
        grid.add(userNameTextField,1,4);

        Label passWord= new Label("密码");
        PasswordField passWordTextField = new PasswordField();
        grid.add(passWord,0,5);
        grid.add(passWordTextField,1,5);

        HBox hbBtn = new HBox(10);
        Button confirm = new Button("确认");
        Button cancel  = new Button("取消");
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().addAll(confirm,cancel);
        grid.add(hbBtn,1,6);

        confirm.setOnAction(event -> {
            Server server = Server.getServer(
                    connectionNameTextField.getText(),
                    hostTextField.getText(),
//                    Integer.parseInt( portTextField.getText()),
                    0,
                    userNameTextField.getText(),
                    passWordTextField.getText()
                    );
            try {
                server.connect();
                System.out.println("server connection succeed");
                listenerVBox.getChildren().clear();
                tableData.refresh();
                int tablesCount = tableData.getTables().size();
                Hyperlink[] option = new Hyperlink[tablesCount];
                for(int i =0;i<tablesCount;i++ ){
                    String tableName = tableData.getTables().get(i);
                    int tableIndex = i;
                    option[i] = new Hyperlink(tableName);
                    option[i].setOnAction(event1 -> {
                        TableView<List<Object>> table = (TableView<List<Object>>)dataTableUI.getChildren().get(0);
                        try {
                            DataTable.reflesh(table,tableName);
                        } catch (Exception e) {
                            System.out.println("具体数据的tableview更新失败");
                        }

                    });
                }

                for(int i = 0; i<tablesCount;i++)
                    listenerVBox.getChildren().add(option[i]);

            }catch (Exception e){
                System.out.println("server connection fail");
                tableData.refresh();
                listenerVBox.getChildren().clear();
            }
            primaryStage.close();

        });



        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
