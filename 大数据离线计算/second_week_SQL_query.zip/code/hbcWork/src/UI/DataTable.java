package UI;

import Data.Server;
import com.sun.xml.internal.bind.v2.runtime.property.PropertyFactory;
import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import Data.detailData;
import org.datanucleus.store.schema.table.Table;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DataTable extends Application {

    private  TableView<List<Object>> table = new TableView<>();
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        Scene scene = new Scene(new Group());
        stage.setTitle("Table View Sample");
        stage.setWidth(900);
        stage.setHeight(800);

        final Label label = new Label("Address Book");
        label.setFont(new Font("Arial", 20));

        table.setEditable(false);


        detailData data = new detailData();
        System.out.println(data.colSchema.get(1));
        int colsCount = data.colSchema.size();
        System.out.println("cols count:"+colsCount);
        for(int i =0; i < colsCount-1; i++ ){
            TableColumn<List<Object>,Object> column = new TableColumn<>(data.colSchema.get(i));
            int columnIndex = i;
            column.setCellValueFactory(cellData ->
                    new SimpleObjectProperty<>(cellData.getValue().get(columnIndex)));
            table.getColumns().add(column);
        }
        table.getItems().setAll(data.rows);



        System.out.println("test");


        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setAlignment(Pos.TOP_CENTER);
        vbox.setPrefWidth(stage.getWidth());
        vbox.setLayoutX(5);
        vbox.prefHeight(scene.getWidth()-100);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table);

        ((Group) scene.getRoot()).getChildren().addAll(vbox);

        stage.setScene(scene);
        stage.show();
    }


    VBox getDataTableUI(String tableName){
        detailData data = new detailData();
        //System.out.println(data.colSchema.get(1));
        int colsCount = data.colSchema.size();
        System.out.println("cols count:"+colsCount);
        for(int i =0; i < colsCount; i++ ){
            TableColumn<List<Object>,Object> column = new TableColumn<>(data.colSchema.get(i));
            int columnIndex = i;
            column.setCellValueFactory(cellData ->
                    new SimpleObjectProperty<>(cellData.getValue().get(columnIndex)));
            table.getColumns().add(column);
        }
        table.getItems().setAll(data.rows);

        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setAlignment(Pos.TOP_CENTER);
        //vbox.setPrefWidth(stage.getWidth());
        vbox.setLayoutX(5);
        //vbox.prefHeight(scene.getWidth()-100);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll( table);
        return vbox;
    }
    public static void reflesh(TableView<List<Object>> table, String tableName) throws Exception {
        Server server = Server.getServer();
        detailData data = server.getDetailData(tableName);
        table.getItems().clear();
        table.getColumns().clear();
        //System.out.println(data.colSchema.get(1));
        int colsCount = data.colSchema.size();
        System.out.println("cols count:"+colsCount);
        for(int i =0; i < colsCount; i++ ){
            TableColumn<List<Object>,Object> column = new TableColumn<>(data.colSchema.get(i));
            int columnIndex = i;
            column.setCellValueFactory(cellData ->
                    new SimpleObjectProperty<>(cellData.getValue().get(columnIndex)));
            table.getColumns().add(column);
        }
        table.getItems().setAll(data.rows);

    }
    public static void refreshWithDetailData(TableView<List<Object>> table, detailData data) throws Exception{
        table.getItems().clear();
        table.getColumns().clear();
        //System.out.println(data.colSchema.get(1));
        int colsCount = data.colSchema.size();
        System.out.println("cols count:"+colsCount);
        for(int i =0; i < colsCount; i++ ){
            TableColumn<List<Object>,Object> column = new TableColumn<>(data.colSchema.get(i));
            int columnIndex = i;
            column.setCellValueFactory(cellData ->
                    new SimpleObjectProperty<>(cellData.getValue().get(columnIndex)));
            table.getColumns().add(column);
        }
        table.getItems().setAll(data.rows);

    }
}