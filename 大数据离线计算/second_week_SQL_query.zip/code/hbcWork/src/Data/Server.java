package Data;

import com.sun.xml.internal.ws.api.message.ExceptionHasMessage;
import javafx.scene.control.TextArea;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private static Server server;
    private Server(String connectionName, String url, int port, String userName, String password)  {
        this.connectionName = connectionName;
        this.url = url;
        this.port = port;
        this.userName = userName;
        this.password = password;
    }
    public static Server getServer(String connectionName, String url, int port, String userName, String password)  {
        //
        server = new Server(connectionName,url, port,userName, password);
        return  server;
    }
    public static Server getServer() throws Exception {
        if(server==null)
            throw new Exception("no server been initialized");
        else
            return server;
    }

    private Connection conn;
    private String connectionName;
    private String url;
    private int port;
    private String userName;
    private String password;
    public void connect() throws SQLException {
        try {
            Class.forName("org.apache.hive.jdbc.HiveDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("url: "+url);
        System.out.println("userName"+userName);
        System.out.println("password"+password);
        conn = DriverManager.getConnection(url,userName,password);

        System.out.println("connect done!");
    }

    public ArrayList<String> getTables() throws SQLException {
        Statement statement = conn.createStatement();
        ResultSet res = statement.executeQuery("show tables");
        ArrayList<String> tables = new ArrayList<>();
        while(res.next()){
            tables.add(res.getString(1));
        }
        return tables;
    }

    public detailData getDetailData(String tableName) throws SQLException {
        ArrayList<String> colSchema = new ArrayList<>();
        List<List<Object>> rows = new ArrayList<>();

        Statement statement = conn.createStatement();
        ResultSet res = statement.executeQuery("desc "+tableName);
        while(res.next()){
            colSchema.add(res.getString(1));
            //System.out.println("col name:"+ res.getString(1));
        }
        int colsCount =  colSchema.size();
        res = statement.executeQuery("select * from "+tableName+" limit 50");
        int rowIndex = 0;
        while(res.next()){
            //System.out.println("row "+rowIndex++);
            List<Object> row = new ArrayList<>();
            for(int i = 1; i<=colsCount;i++){
                row.add(res.getString(i));
            }
            rows.add(row);
        }
        return  new detailData(colSchema,rows);
    }

    public detailData executeSQL(String sqlRequest, TextArea textArea) throws SQLException {
        if(conn==null){
            textArea.appendText("还未建立连接，请先连接！");
            return new detailData();
        }
        Statement statement = conn.createStatement();
        ResultSet resultSet= statement.executeQuery(sqlRequest);
        ArrayList<String> cols = new ArrayList<>();
        List<List<Object>> rows = new ArrayList<>();

        int colsCount = resultSet.getMetaData().getColumnCount();
        for(int i =1; i<=colsCount;i++){
            cols.add(resultSet.getMetaData().getColumnName(i));
        }
        while(resultSet.next()){
            ArrayList<Object> row = new ArrayList<>();
            for(int i =1; i<=colsCount;i++) {
                //textArea.appendText(resultSet.getString(i));
                row.add(resultSet.getString(i));
            }
            rows.add(row);
            textArea.appendText("\n");
        }

        detailData data = new detailData(cols,rows);
        return  data;

//        System.out.println("schema:");
//        for(int i = 0 ; i < cols.size();i++)
//            System.out.print(cols.get(i)+"  ");
//        System.out.println();
//        for(int i = 0; i<rows.size();i++){
//            for(int j =0;j<rows.get(i).size();j++)
//                System.out.println(rows.get(i).get(j)+"  ");
//            System.out.println();
//        }
    }


    public static void main(String[] args) throws SQLException {
        Server server = Server.getServer("1","jdbc:hive2://bigdata115.depts.bingosoft.net:22115/user04_db",1,"user04","1");
        server.connect();
        detailData data = server.getDetailData("hbctemptable");
        System.out.println("cols "+data.getData().colSchema.size());
        for(String name:data.colSchema){
            System.out.println(name);
        }
        for(List<Object> row : data.rows){
            int ind = 0;
            for(Object o :row){
                System.out.print(ind+": "+o.toString()+" ");
                ind++;
            }
            System.out.println();
        }
    }



}
