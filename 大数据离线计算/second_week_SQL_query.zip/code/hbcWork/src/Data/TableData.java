package Data;

import java.util.ArrayList;

public class TableData {
    public ArrayList<String> tables;
    private Server server;
    public TableData(){
//        try{
//            server = Server.getServer();
//            tables = server.getTables();
//        }
//        catch (Exception e){
//            System.out.println("can't get tables");
//            tables = new ArrayList<>();
//        }
        tables = new ArrayList<>();
    }

    public ArrayList<String> getTables(){
        return tables;
    }

    public void refresh(){
        try{
            server = Server.getServer();
            //System.out.println("mark2");
            tables = server.getTables();
        }
        catch (Exception e){
            System.out.println("can't get tables");
            tables = new ArrayList<>();
        }
    }
}
