package Data;

import java.util.ArrayList;
import java.util.List;

public class detailData {
    public ArrayList<String> colSchema;
    public List<List<Object>> rows;
    int colCount;

    //temp initial method
    public detailData(ArrayList<String> colSchema, List<List<Object>> rows){
        this.colSchema = colSchema;
        this.rows = rows;
    }
    public detailData(){
        colSchema = new ArrayList<>();
        rows = new ArrayList<>();
    }
    detailData getData(){
        return  this;
    }
}
